# Materials for ELEC3607 Embedded Systems

#if you make this file will show you to paplay demo iq-16b.wav file then use wspr decoder to decode the signal
#after showing the demo, it will rush bash wsprwait to capture the iq signal and using sox to write into 1 channel and 12000 sample rate wavfile
#the wsprcan/k9an-wsprd will excecute in the readwavfile mode instead of directly reading from the pulseaudio
